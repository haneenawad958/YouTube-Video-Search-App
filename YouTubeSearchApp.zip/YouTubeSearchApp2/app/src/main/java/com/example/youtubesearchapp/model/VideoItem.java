package com.example.youtubesearchapp.model;

public class VideoItem {
    private VideoId id;
    private Snippet snippet;

    public VideoId getId() {
        return id;
    }

    public Snippet getSnippet() {
        return snippet;
    }
}