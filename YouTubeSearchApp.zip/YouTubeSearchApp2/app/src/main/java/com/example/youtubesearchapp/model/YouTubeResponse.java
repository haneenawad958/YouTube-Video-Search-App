package com.example.youtubesearchapp.model;

import java.util.List;

public class YouTubeResponse {
    private List<VideoItem> items;

    public List<VideoItem> getItems() {
        return items;
    }
}
