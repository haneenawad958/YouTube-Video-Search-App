package com.example.youtubesearchapp.model;

public class VideoId {
    private String videoId;

    public String getVideoId() {
        return videoId;
    }
}