package com.example.youtubesearchapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.youtubesearchapp.adapter.VideoAdapter;
import com.example.youtubesearchapp.model.VideoItem;
import com.example.youtubesearchapp.model.YouTubeResponse;
import com.example.youtubesearchapp.network.RetrofitClient;
import com.example.youtubesearchapp.network.YouTubeApiService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private ProgressBar progressBar;
    private TextView messageTextView;
    private RecyclerView videosRecyclerView;

    private VideoAdapter videoAdapter;
    private YouTubeApiService youTubeApiService;

    private static final String API_KEY = "AIzaSyAEk7F_bbhTFUWxwJXDn5fzxviwCJYk7EY";
    private static final int MAX_RESULTS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        progressBar = findViewById(R.id.progressBar);
        messageTextView = findViewById(R.id.messageTextView);
        videosRecyclerView = findViewById(R.id.videosRecyclerView);

        videoAdapter = new VideoAdapter(new ArrayList<>());
        videosRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        videosRecyclerView.setAdapter(videoAdapter);

        youTubeApiService = RetrofitClient
                .getRetrofitInstance()
                .create(YouTubeApiService.class);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = searchEditText.getText().toString().trim();

                if (query.isEmpty()) {
                    showMessage("Please enter a search term.");
                    return;
                }

                searchVideos(query);
            }
        });
    }

    private void searchVideos(String query) {
        showLoading();

        Call<YouTubeResponse> call = youTubeApiService.searchVideos(
                "snippet",
                "video",
                query,
                MAX_RESULTS,
                API_KEY
        );

        call.enqueue(new Callback<YouTubeResponse>() {
            @Override
            public void onResponse(Call<YouTubeResponse> call, Response<YouTubeResponse> response) {
                hideLoading();

                if (!response.isSuccessful()) {
                    showMessage("Error: Unable to fetch videos. Code: " + response.code());
                    return;
                }

                YouTubeResponse youTubeResponse = response.body();

                if (youTubeResponse == null || youTubeResponse.getItems() == null) {
                    showMessage("No results found.");
                    return;
                }

                List<VideoItem> videos = youTubeResponse.getItems();

                if (videos.isEmpty()) {
                    showMessage("No results found.");
                } else {
                    messageTextView.setVisibility(View.GONE);
                    videosRecyclerView.setVisibility(View.VISIBLE);
                    videoAdapter.setVideoList(videos);
                }
            }

            @Override
            public void onFailure(Call<YouTubeResponse> call, Throwable t) {
                hideLoading();
                showMessage("Network error: " + t.getMessage());
            }
        });
    }

    private void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        messageTextView.setVisibility(View.GONE);
        videosRecyclerView.setVisibility(View.GONE);
    }

    private void hideLoading() {
        progressBar.setVisibility(View.GONE);
    }

    private void showMessage(String message) {
        videosRecyclerView.setVisibility(View.GONE);
        messageTextView.setVisibility(View.VISIBLE);
        messageTextView.setText(message);
    }
}