package com.example.youtubesearchapp.model;

public class Thumbnails {
    private Thumbnail medium;
    private Thumbnail high;
    private Thumbnail defaultThumbnail;

    public Thumbnail getMedium() {
        return medium;
    }

    public Thumbnail getHigh() {
        return high;
    }

    public Thumbnail getDefaultThumbnail() {
        return defaultThumbnail;
    }
}
