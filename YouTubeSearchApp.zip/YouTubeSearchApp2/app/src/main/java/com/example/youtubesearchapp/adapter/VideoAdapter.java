package com.example.youtubesearchapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.youtubesearchapp.R;
import com.example.youtubesearchapp.model.Snippet;
import com.example.youtubesearchapp.model.VideoItem;

import java.util.List;
import android.content.Intent;
import android.net.Uri;
public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private List<VideoItem> videoList;

    public VideoAdapter(List<VideoItem> videoList) {
        this.videoList = videoList;
    }

    public void setVideoList(List<VideoItem> videoList) {
        this.videoList = videoList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_video, parent, false);

        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        VideoItem videoItem = videoList.get(position);

        if (videoItem == null || videoItem.getSnippet() == null) {
            return;
        }

        Snippet snippet = videoItem.getSnippet();

        holder.titleTextView.setText(snippet.getTitle());
        holder.channelTextView.setText(snippet.getChannelTitle());
        holder.dateTextView.setText(snippet.getPublishedAt());
        holder.descriptionTextView.setText(snippet.getDescription());

        String thumbnailUrl = "";

        if (snippet.getThumbnails() != null) {
            if (snippet.getThumbnails().getMedium() != null) {
                thumbnailUrl = snippet.getThumbnails().getMedium().getUrl();
            } else if (snippet.getThumbnails().getHigh() != null) {
                thumbnailUrl = snippet.getThumbnails().getHigh().getUrl();
            }

        }

        Glide.with(holder.itemView.getContext())
                .load(thumbnailUrl)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(holder.thumbnailImageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoItem.getId() != null && videoItem.getId().getVideoId() != null) {
                    String videoUrl = "https://www.youtube.com/watch?v=" + videoItem.getId().getVideoId();

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl));
                    holder.itemView.getContext().startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (videoList == null) {
            return 0;
        }
        return videoList.size();
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder {

        ImageView thumbnailImageView;
        TextView titleTextView;
        TextView channelTextView;
        TextView dateTextView;
        TextView descriptionTextView;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);

            thumbnailImageView = itemView.findViewById(R.id.thumbnailImageView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            channelTextView = itemView.findViewById(R.id.channelTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        }
    }
}