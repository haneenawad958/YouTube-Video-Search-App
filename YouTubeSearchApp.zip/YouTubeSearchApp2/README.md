# YouTube Video Search App

## Description
This Android application allows users to search for YouTube videos using the YouTube Data API. Users can enter a search query, view video results in a RecyclerView, and open a selected video in YouTube or a browser.

## Features
- Search YouTube videos by keyword
- Display results in RecyclerView
- Show video title, description, publish time, channel title, and thumbnail
- Load thumbnails using Glide
- Show loading indicator while fetching data
- Handle empty input, network errors, and no results
- Open video when clicking on a result

## Technologies Used
- Java
- Android Studio
- RecyclerView
- Retrofit
- Gson Converter
- Glide
- YouTube Data API v3

## How to Run
1. Clone the repository.
2. Open the project in Android Studio.
3. Make sure the device or emulator has internet access.
4. Run the app.
5. Enter a search term and tap the Search button.

## Assignment Requirements Covered
- User input using EditText
- Search button to trigger API request
- YouTube API request
- RecyclerView for displaying results
- Glide for thumbnail images
- ProgressBar loading feedback
- Error handling for empty input and network/API issues

## Demo
A short video walkthrough is provided through Google Drive.